# Package Name Checker

This package provides a Flask application to check details of apps on the Google Play Store based on package names.
